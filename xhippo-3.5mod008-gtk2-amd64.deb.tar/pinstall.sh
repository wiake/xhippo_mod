#!/bin/sh
[ ! -d ./root/.config/rox.sourceforge.net/SendTo ] || ln -s OpenWith ./root/.config/rox.sourceforge.net/SendTo #thanks shinobar
